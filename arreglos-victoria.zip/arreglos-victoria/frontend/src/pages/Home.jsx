import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div>
      <section className="bg-pink-50 py-20 text-center">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            Flores con Amor y Estilo
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Enviamos arreglos florales frescos a domicilio para toda ocasión.
          </p>
          <Link
            to="/shop"
            className="bg-pink-500 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-pink-600 transition"
          >
            Ver Arreglos
          </Link>
        </div>
      </section>

      <section className="py-12 text-center">
        <h2 className="text-2xl font-bold mb-6">📍 Entregamos en tu ciudad</h2>
        <iframe
          width="100%"
          height="300"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
        ></iframe>
      </section>
    </div>
  );
}
