export default function Contact() {
  return (
    <div className="py-12 px-4 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-8">Contáctanos</h1>
      <p className="text-center text-gray-600 mb-8">
        Escríbenos por WhatsApp, redes sociales o correo.
      </p>

      <div className="grid md:grid-cols-3 gap-8 text-center">
        <div className="p-6 border rounded-lg">
          <h3 className="text-xl font-semibold mb-2">💬 WhatsApp</h3>
          <a
            href="https://wa.me/51999999999?text=Hola,%20quiero%20un%20arreglo"
            className="text-green-500 hover:underline"
          >
            Chatea con nosotros
          </a>
        </div>

        <div className="p-6 border rounded-lg">
          <h3 className="text-xl font-semibold mb-2">📧 Correo</h3>
          <p>arreglosvictoriafloreria@gmail.com</p>
        </div>

        <div className="p-6 border rounded-lg">
          <h3 className="text-xl font-semibold mb-2">📱 Redes</h3>
          <div className="space-y-2">
            <div>
              <a href="https://facebook.com/arreglosvictoriafloreria" className="text-blue-600 hover:underline">
                Facebook
              </a>
            </div>
            <div>
              <a href="https://instagram.com/arreglosvictoria" className="text-pink-600 hover:underline">
                Instagram
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
