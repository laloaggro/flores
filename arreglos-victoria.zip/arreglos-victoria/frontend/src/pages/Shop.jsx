import { useCart } from '../context/CartContext';
import ProductCard from '../components/ProductCard';

export default function Shop() {
  const { addToCart } = useCart();

  const products = [
    {
      id: 1,
      name: "Ramo de 12 Rosas Rojas",
      price: 85,
      image_url: "https://res.cloudinary.com/dkzmsk7qv/image/upload/v1719500000/rosas-rojas.jpg"
    },
    {
      id: 2,
      name: "Arreglo de Tulipanes",
      price: 120,
      image_url: "https://res.cloudinary.com/dkzmsk7qv/image/upload/v1719500000/tulipanes.jpg"
    },
    {
      id: 3,
      name: "Centro de Orquídeas",
      price: 150,
      image_url: "https://res.cloudinary.com/dkzmsk7qv/image/upload/v1719500000/orquideas.jpg"
    },
  ];

  return (
    <div className="py-12 px-4">
      <h1 className="text-3xl font-bold text-center mb-8">Nuestros Arreglos</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onAddToCart={addToCart}
          />
        ))}
      </div>
    </div>
  );
}
