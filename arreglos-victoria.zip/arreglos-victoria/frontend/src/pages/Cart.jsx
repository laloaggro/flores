import { useCart } from '../context/CartContext';
import { useState } from 'react';
import { Link } from 'react-router-dom';

export default function Cart() {
  const { cart, removeFromCart, clearCart } = useCart();
  const [form, setForm] = useState({
    name: '',
    phone: '',
    address: '',
    deliveryDate: ''
  });

  const total = cart.items.reduce((sum, item) => sum + item.price, 0);

  const handleSubmit = (e) => {
    e.preventDefault();
    const order = { ...form, items: cart.items, total };
    alert('Pedido confirmado: Gracias por tu compra. Nos contactaremos contigo.');
    console.log('Pedido:', order);
    clearCart();
  };

  if (cart.items.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-xl">Tu carrito está vacío</p>
        <Link to="/shop" className="text-pink-500 hover:underline">Ir a la tienda</Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Tu Pedido</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          {cart.items.map((item, index) => (
            <div key={index} className="flex justify-between border-b py-2">
              <span>{item.name}</span>
              <span>S/. {item.price}</span>
              <button
                onClick={() => removeFromCart(index)}
                className="text-red-500 ml-2"
              >
                ✕
              </button>
            </div>
          ))}
          <div className="font-bold mt-4">Total: S/. {total}</div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <h2 className="text-xl font-semibold">Datos de Entrega</h2>
          <input
            type="text"
            placeholder="Nombre"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full p-2 border rounded"
            required
          />
          <input
            type="text"
            placeholder="Teléfono"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="w-full p-2 border rounded"
            required
          />
          <input
            type="text"
            placeholder="Dirección"
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
            className="w-full p-2 border rounded"
            required
          />
          <input
            type="date"
            value={form.deliveryDate}
            onChange={(e) => setForm({ ...form, deliveryDate: e.target.value })}
            className="w-full p-2 border rounded"
            required
          />
          <button
            type="submit"
            className="w-full bg-green-500 text-white py-2 rounded hover:bg-green-600"
          >
            Confirmar Pedido
          </button>
        </form>
      </div>
    </div>
  );
}
