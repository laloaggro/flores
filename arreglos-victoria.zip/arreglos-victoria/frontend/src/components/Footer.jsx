export default function Footer() {
  return (
    <footer className="bg-gray-100 py-8 mt-12">
      <div className="max-w-6xl mx-auto px-4 text-center">
        <h3 className="text-xl font-bold text-gray-800 mb-4">🌸 Arreglos Victoria Florería</h3>
        <p className="text-gray-600 mb-4">
          Flores frescas con entrega a domicilio en tu ciudad.
        </p>
        <div className="space-x-6 mb-4">
          <a href="https://wa.me/51999999999?text=Hola,%20quiero%20un%20arreglo" className="text-green-500 hover:underline">
            💬 WhatsApp
          </a>
          <a href="https://www.facebook.com/arreglosvictoriafloreria" className="text-blue-600 hover:underline">
            📘 Facebook
          </a>
          <a href="https://www.instagram.com/arreglosvictoria/" className="text-pink-600 hover:underline">
            📸 Instagram
          </a>
        </div>
        <p className="text-sm text-gray-500">
          Correo: arreglosvictoriafloreria@gmail.com
        </p>
      </div>
    </footer>
  );
}
