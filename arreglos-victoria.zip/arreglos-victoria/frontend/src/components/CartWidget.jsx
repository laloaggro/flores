import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

export default function CartWidget() {
  const { cart } = useCart();
  const totalItems = cart.items.length;

  return (
    <Link to="/cart" className="relative">
      <span>🛒</span>
      {totalItems > 0 && (
        <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 text-xs flex items-center justify-center">
          {totalItems}
        </span>
      )}
    </Link>
  );
}
