import { Link } from 'react-router-dom';
import CartWidget from './CartWidget';

export default function Navbar() {
  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-pink-600">
          🌸 Arreglos Victoria
        </Link>
        <div className="space-x-6">
          <Link to="/" className="hover:text-pink-500">Inicio</Link>
          <Link to="/shop" className="hover:text-pink-500">Tienda</Link>
          <Link to="/contact" className="hover:text-pink-500">Contacto</Link>
          <CartWidget />
        </div>
      </div>
    </nav>
  );
}
