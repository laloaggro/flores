export default function ProductCard({ product, onAddToCart }) {
  return (
    <div className="border rounded-lg overflow-hidden shadow hover:shadow-lg transition">
      <img
        src={product.image_url}
        alt={product.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="font-bold text-gray-800">{product.name}</h3>
        <p className="text-green-600 font-semibold">S/. {product.price}</p>
        <button
          onClick={() => onAddToCart(product)}
          className="mt-2 bg-pink-500 text-white px-4 py-2 rounded hover:bg-pink-600 w-full transition"
        >
          + Agregar
        </button>
      </div>
    </div>
  );
}
